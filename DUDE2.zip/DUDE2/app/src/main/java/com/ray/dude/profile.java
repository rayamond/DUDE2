package com.ray.dude;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class profile extends AppCompatActivity {
    ImageView imageview4;
    TextView editText4;
    TextView editText5;
    TextView editText6;
    TextView editText7;
    TextView editText8;
    TextView editText9;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        imageview4  = findViewById(R.id.imageView4);
        editText4 =  findViewById(R.id.editText4);
        editText5 =  findViewById(R.id.editText5);
        editText6 =  findViewById(R.id.editText6);
        editText7 =  findViewById(R.id.editText7);
        editText8 =  findViewById(R.id.editText8);
        editText9 =  findViewById(R.id.editText9);


    }
}
